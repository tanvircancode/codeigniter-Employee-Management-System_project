	<?php
		defined('BASEPATH') OR exit('No direct script access allowed');
	?>
	    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
	    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	  </body>
	</html>